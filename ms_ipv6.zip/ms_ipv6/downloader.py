"""
Core functionality for ModelScope downloads
"""

import fnmatch
import json
import logging
import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from threading import Lock
from typing import Any, Dict, List, Optional, Union

import requests
from tqdm import tqdm

from .schema import Plan, PlanFile

logger = logging.getLogger(__name__)


class ModelScopeDownloader:
    """ModelScope下载器类"""

    def __init__(self, cache_dir: Optional[str] = None, use_ipv6: bool = False):
        """
        初始化下载器

        Args:
            cache_dir: 缓存目录
            use_ipv6: 是否使用IPV6
        """
        self.cache_dir = cache_dir or os.path.expanduser("~/.cache/ms_ipv6")
        self.use_ipv6 = use_ipv6

        # 确保缓存目录存在
        os.makedirs(self.cache_dir, exist_ok=True)

    def download_model(self, model_id: str, output_dir: str = ".") -> bool:
        """
        下载模型

        Args:
            model_id: 模型ID
            output_dir: 输出目录

        Returns:
            是否下载成功
        """
        logger.info(f"开始下载模型: {model_id}")
        logger.info(f"输出目录: {output_dir}")
        logger.info(f"缓存目录: {self.cache_dir}")
        logger.info(f"使用IPV6: {self.use_ipv6}")

        # TODO: 实现实际的下载逻辑
        print("ModelScope下载功能正在开发中...")
        return False

    def get_model_info(self, model_id: str) -> Dict[str, Any]:
        """
        获取模型信息

        Args:
            model_id: 模型ID

        Returns:
            模型信息字典
        """
        logger.info(f"获取模型信息: {model_id}")

        # TODO: 实现实际的模型信息获取逻辑
        return {"model_id": model_id, "status": "功能开发中"}

    def list_available_models(self) -> list:
        """
        列出可用模型

        Returns:
            模型列表
        """
        logger.info("获取可用模型列表")

        # TODO: 实现实际的模型列表功能
        return []

    def download_from_plan(
        self,
        plan_path: str,
        *,
        local_dir: str,
        workers: int = 4,
        overwrite: bool = False,
        skip_existing: bool = True,
        timeout: int = 60,
        only_raw: bool = False,
        only_no_raw: bool = False,
    ) -> Dict[str, Any]:
        """
        根据计划文件下载所有条目。

        Args:
            plan_path: 计划文件路径（_msv6.json）
            local_dir: 本地保存根目录（必填）
            workers: 并发线程数
            overwrite: 是否覆盖已存在文件
            skip_existing: 已存在文件是否跳过（当 overwrite=False 时生效）
            timeout: HTTP 请求超时秒数
            only_raw: 仅下载带 raw_url 的文件
            only_no_raw: 仅下载不带 raw_url 的文件

        Returns:
            下载结果统计信息字典
        """
        # 读取计划
        with open(plan_path, encoding="utf-8") as f:
            plan: Plan = json.load(f)

        files: List[PlanFile] = plan.get("files", [])  # type: ignore[assignment]
        if not isinstance(files, list):
            raise ValueError("计划文件不合法：缺少 files")

        # 默认策略：未指定时仅下载带 raw_url 的条目
        if not only_raw and not only_no_raw:
            only_raw = True

        # 策略互斥校验
        if only_raw and only_no_raw:
            raise ValueError("参数冲突：--only-raw 与 --only-no-raw 不能同时使用")

        # 按策略过滤
        if only_raw:
            files = [f for f in files if f.get("raw_url")]
        elif only_no_raw:
            files = [f for f in files if not f.get("raw_url")]

        # 根据大小从小到大排序；未知大小（None 或缺失）排后
        def _size_key(f: PlanFile):
            size_val = f.get("size")
            has_size = isinstance(size_val, int)
            return (0 if has_size else 1, size_val if has_size else 0, f.get("path", ""))

        files = sorted(files, key=_size_key)

        root_dir = os.path.abspath(local_dir)
        os.makedirs(root_dir, exist_ok=True)

        total = len(files)
        success = 0
        skipped = 0
        failed = 0
        results: List[Dict[str, Any]] = []

        # 进度条设置
        all_have_sizes = total > 0 and all(isinstance(f.get("size"), int) for f in files)
        overall_mode = "bytes" if all_have_sizes else "count"
        overall_total = (
            sum(int(f["size"]) for f in files) if overall_mode == "bytes" else total
        )
        overall_bar = tqdm(
            total=overall_total,
            unit="B" if overall_mode == "bytes" else "file",
            unit_scale=True if overall_mode == "bytes" else False,
            desc="总进度",
        )
        sequential = workers <= 1
        lock = Lock()

        def _download_one(item: PlanFile) -> Dict[str, Any]:
            # 优先使用 raw_url（通常指向支持 IPv6 的 CDN 直链）
            url = item.get("raw_url") or item["url"]
            rel_path = item["path"]  # 相对路径
            target = os.path.join(root_dir, rel_path)
            os.makedirs(os.path.dirname(target), exist_ok=True)

            # 已存在处理
            if os.path.exists(target) and not overwrite:
                if skip_existing:
                    # 跳过时更新总进度
                    if overall_mode == "count":
                        if sequential:
                            overall_bar.update(1)
                        else:
                            with lock:
                                overall_bar.update(1)
                    elif overall_mode == "bytes" and isinstance(item.get("size"), int):
                        size_delta = int(item["size"])  # 仅在已知大小时更新
                        if sequential:
                            overall_bar.update(size_delta)
                        else:
                            with lock:
                                overall_bar.update(size_delta)
                    # 显示当前文件
                    overall_bar.write(f"跳过: {rel_path} (已存在)")
                    return {"path": rel_path, "status": "skipped"}

            # 当前文件进度条（仅顺序下载时展示）
            file_bar = None
            try:
                if sequential:
                    # 在顺序模式下将总进度条描述改为当前文件
                    overall_bar.set_description(f"总进度 | 正在下载: {rel_path}")
                if sequential and isinstance(item.get("size"), int):
                    file_bar = tqdm(
                        total=int(item["size"]),
                        unit="B",
                        unit_scale=True,
                        desc=f"下载 {rel_path}",
                        leave=False,
                    )

                # 提示开始下载的文件（并发/顺序均可见）
                overall_bar.write(
                    f"开始下载: {rel_path} ({'raw' if item.get('raw_url') else 'origin'})"
                )

                tmp_path = target + ".part"
                with requests.get(url, stream=True, timeout=timeout) as r:
                    r.raise_for_status()
                    with open(tmp_path, "wb") as wf:
                        for chunk in r.iter_content(chunk_size=1024 * 1024):
                            if not chunk:
                                continue
                            wf.write(chunk)
                            # 更新单文件与总进度
                            if file_bar is not None:
                                file_bar.update(len(chunk))
                            if overall_mode == "bytes":
                                if sequential:
                                    overall_bar.update(len(chunk))
                                else:
                                    with lock:
                                        overall_bar.update(len(chunk))
                os.replace(tmp_path, target)

                # 大小校验（如有）
                expected = item.get("size")
                if expected is not None:
                    try:
                        if int(expected) != os.path.getsize(target):
                            return {"path": rel_path, "status": "size-mismatch"}
                    except Exception:  # noqa: BLE001
                        pass

                # 若以文件计数作为总进度，完成后+1
                if overall_mode == "count":
                    if sequential:
                        overall_bar.update(1)
                    else:
                        with lock:
                            overall_bar.update(1)
                # 提示完成
                overall_bar.write(f"完成: {rel_path}")
                return {"path": rel_path, "status": "ok"}
            except Exception as e:  # noqa: BLE001
                # 清理临时文件
                try:
                    if os.path.exists(tmp_path):
                        os.remove(tmp_path)
                except Exception:  # noqa: BLE001
                    pass
                overall_bar.write(f"失败: {rel_path} -> {e}")
                return {"path": rel_path, "status": "error", "error": str(e)}
            finally:
                if file_bar is not None:
                    file_bar.close()

        if sequential:
            for item in files:
                results.append(_download_one(item))
        else:
            with ThreadPoolExecutor(max_workers=workers) as ex:
                future_map = {ex.submit(_download_one, item): item for item in files}
                for fut in as_completed(future_map):
                    res = fut.result()
                    results.append(res)

        overall_bar.close()

        for r in results:
            if r["status"] == "ok":
                success += 1
            elif r["status"] == "skipped":
                skipped += 1
            else:
                failed += 1

        summary = {
            "total": total,
            "success": success,
            "skipped": skipped,
            "failed": failed,
        }
        logger.info("下载完成：%s", summary)
        return summary

    # --- 新增：生成下载计划 ---
    def generate_plan(
        self,
        *,
        repo_type: str,
        repo_id: str,
        output: Optional[str] = None,
        allow_pattern: Optional[Union[str, List[str]]] = None,
        ignore_pattern: Optional[Union[str, List[str]]] = None,
    ) -> str:
        """
        生成下载计划文件（不包含本地根目录）。

        Args:
            repo_type: 仓库类型，"model" 或 "dataset"
            repo_id: 仓库ID，如 "user/repo"
            output: 计划文件输出路径（.json）。若未提供，默认输出到
                    repo_type__<repo_id>（将 repo_id 中的 '/' 替换为 '__'）.json。
            allow_pattern: 允许下载的通配模式（可多值）
            ignore_pattern: 忽略下载的通配模式（可多值）

        Returns:
            计划文件路径（最终写入的位置）
        """
        # 惰性导入，避免在未安装modelscope时出错
        try:
            from modelscope.hub.api import HubApi, ModelScopeConfig
            from modelscope.hub.file_download import get_file_download_url
            from modelscope.utils.constant import (
                DEFAULT_DATASET_REVISION,
                DEFAULT_MODEL_REVISION,
                REPO_TYPE_DATASET,
                REPO_TYPE_MODEL,
            )
        except Exception as e:  # noqa: BLE001
            raise RuntimeError(
                "需要已安装的 'modelscope' 包以生成下载计划"
            ) from e

        if repo_type not in {"model", "dataset"}:
            raise ValueError("repo_type 仅支持 'model' 或 'dataset'")

        ms_repo_type = REPO_TYPE_MODEL if repo_type == "model" else REPO_TYPE_DATASET

        api = HubApi()
        endpoint = api.get_endpoint_for_read(repo_id=repo_id, repo_type=ms_repo_type)
        cookies = ModelScopeConfig.get_cookies()

        # 获取文件列表与修订信息
        if repo_type == "model":
            revision_detail = api.get_valid_revision_detail(
                repo_id, revision=DEFAULT_MODEL_REVISION, cookies=cookies, endpoint=endpoint
            )
            revision = revision_detail["Revision"]
            headers = {"Snapshot": "True", "user-agent": ModelScopeConfig.get_user_agent(user_agent=None)}
            repo_files = api.get_model_files(
                model_id=repo_id,
                revision=revision,
                recursive=True,
                use_cookies=False if cookies is None else cookies,
                headers=headers,
                endpoint=endpoint,
            )
        else:
            revision = DEFAULT_DATASET_REVISION
            # 分页获取dataset文件列表
            page_number = 1
            page_size = 150
            repo_files = []
            while True:
                dataset_files = api.get_dataset_files(
                    repo_id=repo_id,
                    revision=revision,
                    root_path="/",
                    recursive=True,
                    page_number=page_number,
                    page_size=page_size,
                    endpoint=endpoint,
                )
                repo_files.extend(dataset_files)
                if len(dataset_files) < page_size:
                    break
                page_number += 1

        # 归一化模式并过滤
        def _normalize_patterns(patterns: Optional[Union[str, List[str]]]) -> Optional[List[str]]:
            if patterns is None:
                return None
            if isinstance(patterns, str):
                patterns = [p.strip() for p in patterns.split(",") if p.strip()]
            # 展平嵌套
            flat: List[str] = []
            for p in patterns:
                if isinstance(p, str):
                    flat.append(p)
                else:
                    # 忽略非字符串
                    continue
            # 目录模式以/结尾时自动匹配其下所有
            return [item if not item.endswith("/") else item + "*" for item in flat]

        allow_patterns = _normalize_patterns(allow_pattern)
        ignore_patterns = _normalize_patterns(ignore_pattern)

        filtered_files: List[Dict[str, Any]] = []
        for f in repo_files:
            if f.get("Type") == "tree":
                continue
            path = f.get("Path") or f.get("Name")
            if not path:
                continue
            if ignore_patterns and any(fnmatch.fnmatch(path, pat) for pat in ignore_patterns):
                continue
            if allow_patterns and not any(fnmatch.fnmatch(path, pat) for pat in allow_patterns):
                continue
            filtered_files.append(f)

        # 解析重定向，获得可用的 raw_url（不下载，仅做跳转探测）
        def _resolve_raw_url(u: str, *, headers: Optional[Dict[str, str]] = None, cookies=None) -> Optional[str]:
            try:
                # 允许重定向，拿最终的 URL；使用 stream 避免下载主体
                r = requests.get(
                    u,
                    allow_redirects=True,
                    stream=True,
                    timeout=10,
                    headers=headers,
                    cookies=cookies,
                )
                try:
                    # 存在重定向历史并且最终 URL 与原始不同，则视为直链
                    if getattr(r, "history", None) and r.url and r.url != u:
                        return r.url
                finally:
                    r.close()
            except Exception:
                return None
            return None

        # 生成计划条目（使用相对路径）
        plan_files: List[PlanFile] = []
        for f in filtered_files:
            remote_path = f["Path"]
            if repo_type == "model":
                url = get_file_download_url(
                    model_id=repo_id,
                    file_path=remote_path,
                    revision=revision,
                    endpoint=endpoint,
                )
            else:
                group_or_owner, name = repo_id.split("/", 1)
                url = api.get_dataset_file_url(
                    file_name=remote_path,
                    dataset_name=name,
                    namespace=group_or_owner,
                    revision=revision,
                    endpoint=endpoint,
                )
            rel_path = os.path.normpath(remote_path)
            # 传入 headers/cookies 以获得与 API 一致的跳转行为
            raw = _resolve_raw_url(url, headers=headers if repo_type == "model" else None, cookies=cookies)
            entry: PlanFile = {
                "url": url,
                "path": rel_path,
                "remote_path": remote_path,
                "size": f.get("Size"),
            }
            if raw:
                entry["raw_url"] = raw
            plan_files.append(entry)

        # 写入计划文件（无 local_dir/root_dir）
        plan: Plan = {
            "repo_id": repo_id,
            "repo_type": repo_type,
            "endpoint": endpoint,
            "revision": revision,
            "file_count": len(plan_files),
            "files": plan_files,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "version": 1,
        }

        # 计算默认输出路径：repo_type__<repo_id替换为__>.json（不创建子目录）
        if not output:
            sanitized = repo_id.replace("/", "__")
            output = f"{repo_type}__{sanitized}.json"

        plan_path = os.path.abspath(output)
        out_dir = os.path.dirname(plan_path)
        if out_dir:
            os.makedirs(out_dir, exist_ok=True)
        with open(plan_path, "w", encoding="utf-8") as f:
            json.dump(plan, f, ensure_ascii=False, indent=2)

        logger.info("下载计划已生成: %s (共 %d 个文件)", plan_path, len(plan_files))
        return plan_path
